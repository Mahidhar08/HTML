const quiz = document.getElementById('quiz');
const scoreDisplay = document.getElementById('score');
const startButton = document.getElementById('start');
const nextButton = document.getElementById('next');

let currentQuestionIndex = 0;
let score = 0;

const questions = [
  {
    question: "What is the capital of France?",
    answers: ["Paris", "London", "Berlin", "Rome"],
    correctAnswer: "Paris"
  },
  {
    question: "What is the highest mountain in the world?",
    answers: ["Mount Everest", "K2", "Kangchenjunga", "Lhotse"],
    correctAnswer: "Mount Everest"
  },
  {
    question: "What is the largest planet in our solar system?",
    answers: ["Jupiter", "Saturn", "Mars", "Earth"],
    correctAnswer: "Jupiter"
  }
];

function startQuiz() {
  startButton.style.display = 'none';
  nextButton.style.display = 'inline';
  displayQuestion();
}

function displayQuestion() {
  const currentQuestion = questions[currentQuestionIndex];
  quiz.innerHTML = `
    <h2>${currentQuestion.question}</h2>
    <ul>
      ${currentQuestion.answers.map(answer => `<li><button onclick="checkAnswer('${answer}')">${answer}</button></li>`).join('')}
    </ul>
  `;
}

function checkAnswer(selectedAnswer) {
  const currentQuestion = questions[currentQuestionIndex];
  if (selectedAnswer === currentQuestion.correctAnswer) {
    score++;
  }
  currentQuestionIndex++;
  if (currentQuestionIndex < questions.length) {
    displayQuestion();
  } else {
    endQuiz();
  }
}

function endQuiz() {
  quiz.innerHTML = `<h2>Quiz Finished!</h2><p>Your Score: ${score}</p>`;
  nextButton.style.display = 'none';
  startButton.style.display = 'inline';
}

startButton.addEventListener('click', startQuiz);
nextButton.addEventListener('click', startQuiz);